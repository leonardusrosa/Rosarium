/*
  # Create user intentions table

  1. New Tables
    - `user_intentions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `intention` (text, the prayer intention)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `user_intentions` table
    - Add policy for authenticated users to manage their own intentions
*/

CREATE TABLE IF NOT EXISTS user_intentions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  intention text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_intentions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own intentions"
  ON user_intentions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);