/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        cathedral: {
          stone: '#44403c',
          gold: '#d97706',
          light: '#f5f5f4',
          shadow: '#1c1917',
          amber: '#f59e0b',
          rose: '#e11d48',
        }
      },
      fontFamily: {
        cinzel: ['Cinzel', 'serif'],
        crimson: ['Crimson Text', 'serif'],
        cormorant: ['Cormorant Garamond', 'serif'],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-cathedral': 'linear-gradient(135deg, rgba(68, 64, 60, 0.1), rgba(28, 25, 23, 0.1))',
        'stone-texture': `
          radial-gradient(circle at 20% 50%, rgba(120, 113, 108, 0.1) 0%, transparent 50%),
          radial-gradient(circle at 80% 20%, rgba(87, 83, 78, 0.1) 0%, transparent 50%),
          radial-gradient(circle at 40% 80%, rgba(68, 64, 60, 0.1) 0%, transparent 50%)
        `,
      },
      animation: {
        'cathedral-glow': 'cathedral-glow 4s ease-in-out infinite',
        'sacred-pulse': 'sacred-pulse 3s ease-in-out infinite',
        'gothic-flow': 'gothic-flow 8s ease-in-out infinite',
      },
      keyframes: {
        'cathedral-glow': {
          '0%, 100%': {
            boxShadow: '0 0 20px rgba(217, 119, 6, 0.2)',
          },
          '50%': {
            boxShadow: '0 0 30px rgba(217, 119, 6, 0.4)',
          },
        },
        'sacred-pulse': {
          '0%, 100%': {
            opacity: '0.7',
            transform: 'scale(1)',
          },
          '50%': {
            opacity: '1',
            transform: 'scale(1.02)',
          },
        },
        'gothic-flow': {
          '0%, 100%': {
            transform: 'translateY(0px)',
          },
          '50%': {
            transform: 'translateY(-5px)',
          },
        },
      },
      backdropBlur: {
        'cathedral': '16px',
      },
      boxShadow: {
        'cathedral': '0 25px 50px -12px rgba(0, 0, 0, 0.8)',
        'gothic': '0 10px 25px -5px rgba(0, 0, 0, 0.6)',
      },
    },
  },
  plugins: [],
};