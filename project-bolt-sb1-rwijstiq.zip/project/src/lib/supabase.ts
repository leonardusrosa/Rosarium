import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

// Only create client if both URL and key are provided and not placeholder values
if (!supabaseUrl || !supabaseAnonKey || 
    supabaseUrl.includes('placeholder') || 
    supabaseAnonKey.includes('placeholder')) {
  console.warn('Supabase configuration not found. Please set up your environment variables.')
}

export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co', 
  supabaseAnonKey || 'placeholder-anon-key'
)

export interface UserIntention {
  id?: string
  user_id: string
  intention: string
  created_at?: string
}

export interface PrayerProgress {
  id?: string
  user_id: string
  mystery_type: string
  completed_at: string
  current_bead: number
}