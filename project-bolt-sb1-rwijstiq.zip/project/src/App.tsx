import React, { useState } from 'react'
import { StarfieldBackground } from './components/StarfieldBackground'
import { Sidebar } from './components/Sidebar'
import { PrayerContent } from './components/PrayerContent'
import { IntentionsModal } from './components/IntentionsModal'
import { AuthModal } from './components/AuthModal'
import { useAuth } from './hooks/useAuth'

function App() {
  const [currentSection, setCurrentSection] = useState('initium')
  const [isIntentionsModalOpen, setIsIntentionsModalOpen] = useState(false)
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false)
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden">
        <StarfieldBackground />
        <div className="text-center z-10">
          <div className="text-6xl text-amber-400 mb-6 animate-pulse drop-shadow-2xl font-cinzel">✠</div>
          <p className="text-stone-300 text-xl font-light tracking-wider font-cormorant">
            Carregando...
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      <StarfieldBackground />
      
      {/* Gothic cathedral atmosphere overlay */}
      <div className="fixed inset-0 bg-gradient-to-b from-slate-900/10 via-transparent to-slate-900/20 pointer-events-none z-5"></div>
      
      <div className="flex relative z-10">
        <Sidebar 
          currentSection={currentSection}
          onSectionChange={setCurrentSection}
          onOpenIntentions={() => setIsIntentionsModalOpen(true)}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          isAuthenticated={!!user}
        />
        
        <PrayerContent 
          section={currentSection}
          onOpenIntentions={() => setIsIntentionsModalOpen(true)}
          onOpenAuth={() => setIsAuthModalOpen(true)}
          isAuthenticated={!!user}
        />
      </div>

      <IntentionsModal 
        isOpen={isIntentionsModalOpen}
        onClose={() => setIsIntentionsModalOpen(false)}
      />

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  )
}

export default App