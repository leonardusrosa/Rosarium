import { useState, useEffect } from 'react'
import { supabase, UserIntention } from '../lib/supabase'
import { useAuth } from './useAuth'

export function useIntentions() {
  const [intentions, setIntentions] = useState<UserIntention[]>([])
  const [loading, setLoading] = useState(false)
  const { user } = useAuth()

  const fetchIntentions = async () => {
    if (!user) {
      setIntentions([])
      return
    }

    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('user_intentions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (error) {
        console.error('Error fetching intentions:', error)
        setIntentions([])
      } else {
        setIntentions(data || [])
      }
    } catch (err) {
      console.error('Unexpected error fetching intentions:', err)
      setIntentions([])
    } finally {
      setLoading(false)
    }
  }

  const addIntention = async (intention: string) => {
    if (!user) return { error: new Error('User not authenticated') }

    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('user_intentions')
        .insert([
          {
            user_id: user.id,
            intention: intention.trim(),
          },
        ])
        .select()
        .single()

      if (!error && data) {
        setIntentions(prev => [data, ...prev])
      }

      return { data, error }
    } catch (err) {
      console.error('Unexpected error adding intention:', err)
      return { data: null, error: err as Error }
    } finally {
      setLoading(false)
    }
  }

  const removeIntention = async (id: string) => {
    if (!user) return { error: new Error('User not authenticated') }

    setLoading(true)
    try {
      const { error } = await supabase
        .from('user_intentions')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id) // Extra security check

      if (!error) {
        setIntentions(prev => prev.filter(intention => intention.id !== id))
      }

      return { error }
    } catch (err) {
      console.error('Unexpected error removing intention:', err)
      return { error: err as Error }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchIntentions()
  }, [user])

  return {
    intentions,
    loading,
    addIntention,
    removeIntention,
    fetchIntentions,
  }
}