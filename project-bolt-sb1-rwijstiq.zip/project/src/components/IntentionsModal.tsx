import React, { useState } from 'react'
import { X, Plus, Trash2, Heart } from 'lucide-react'
import { useIntentions } from '../hooks/useIntentions'

interface IntentionsModalProps {
  isOpen: boolean
  onClose: () => void
}

export function IntentionsModal({ isOpen, onClose }: IntentionsModalProps) {
  const [newIntention, setNewIntention] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { intentions, addIntention, removeIntention, loading } = useIntentions()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newIntention.trim() || isSubmitting) return

    setIsSubmitting(true)
    try {
      const { error } = await addIntention(newIntention.trim())
      if (!error) {
        setNewIntention('')
      } else {
        console.error('Error adding intention:', error)
      }
    } catch (err) {
      console.error('Unexpected error:', err)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleRemove = async (id: string) => {
    try {
      const { error } = await removeIntention(id)
      if (error) {
        console.error('Error removing intention:', error)
      }
    } catch (err) {
      console.error('Unexpected error:', err)
    }
  }

  if (!isOpen) return null

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      {/* Gothic cathedral backdrop */}
      <div className="absolute inset-0 bg-black/90 backdrop-blur-sm"></div>
      
      {/* Modal */}
      <div 
        className="relative bg-stone-900/90 backdrop-blur-sm rounded-lg border border-stone-700/50 max-w-2xl w-full max-h-[85vh] overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Gothic architectural elements */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-rose-600/40 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-rose-600/40 to-transparent"></div>
        
        {/* Gothic corner details */}
        <div className="absolute top-4 left-4 text-rose-600/30 text-2xl font-cinzel">⚜</div>
        <div className="absolute top-4 right-4 text-rose-600/30 text-2xl font-cinzel">⚜</div>
        <div className="absolute bottom-4 left-4 text-rose-600/30 text-2xl font-cinzel">⚜</div>
        <div className="absolute bottom-4 right-4 text-rose-600/30 text-2xl font-cinzel">⚜</div>
        
        <div className="relative p-10">
          {/* Sacred Header */}
          <div className="flex items-center justify-between mb-10">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-stone-800/40 rounded-lg border border-rose-500/30">
                <Heart className="w-8 h-8 text-rose-400" />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-rose-300 font-cinzel">
                  Intentiones Orationes
                </h2>
                <p className="text-lg text-stone-400 font-cormorant">
                  Intenções de Oração
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-3 rounded-lg hover:bg-stone-800/50 transition-all duration-300 text-stone-400 hover:text-stone-200"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Add new intention */}
          <form onSubmit={handleSubmit} className="mb-8">
            <div className="flex space-x-4">
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={newIntention}
                  onChange={(e) => setNewIntention(e.target.value)}
                  placeholder="Escreva sua intenção de oração..."
                  disabled={isSubmitting}
                  className="w-full px-6 py-4 bg-stone-900/40 border border-stone-700/40 rounded-lg text-stone-200 placeholder-stone-500 focus:outline-none focus:border-rose-600/50 focus:ring-2 focus:ring-rose-600/20 text-lg font-crimson transition-all duration-300 disabled:opacity-50"
                />
              </div>
              <button
                type="submit"
                disabled={!newIntention.trim() || isSubmitting}
                className="px-6 py-4 bg-stone-800/40 border border-rose-600/30 rounded-lg text-rose-300 hover:bg-stone-700/50 hover:border-rose-500/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
              >
                {isSubmitting ? (
                  <div className="w-6 h-6 border-2 border-rose-300/30 border-t-rose-300 rounded-full animate-spin"></div>
                ) : (
                  <Plus className="w-6 h-6" />
                )}
              </button>
            </div>
          </form>

          {/* Intentions list */}
          <div className="space-y-4 max-h-80 overflow-y-auto pr-2">
            {loading && intentions.length === 0 ? (
              <div className="text-center py-16 text-stone-500">
                <div className="w-8 h-8 border-2 border-stone-500/30 border-t-stone-500 rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-lg font-crimson">Carregando intenções...</p>
              </div>
            ) : intentions.length === 0 ? (
              <div className="text-center py-16 text-stone-500">
                <div className="mb-6">
                  <Heart className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p className="text-xl font-crimson">
                    Nenhuma intenção adicionada ainda
                  </p>
                  <p className="text-sm mt-2 opacity-75 font-cormorant">
                    Adicione suas intenções de oração para que sejam lembradas durante o Rosário
                  </p>
                </div>
              </div>
            ) : (
              intentions.map((intention, index) => (
                <div
                  key={intention.id}
                  className="flex items-start justify-between p-6 bg-stone-900/20 border border-stone-700/30 rounded-lg group hover:bg-stone-800/30 hover:border-stone-600/40 transition-all duration-300"
                >
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="flex-shrink-0 mt-1">
                      <div className="w-8 h-8 bg-stone-800/40 rounded-full border border-rose-500/30 flex items-center justify-center">
                        <Heart className="w-4 h-4 text-rose-400" />
                      </div>
                    </div>
                    <p className="text-stone-200 flex-1 leading-relaxed text-lg font-crimson">
                      {intention.intention}
                    </p>
                  </div>
                  <button
                    onClick={() => handleRemove(intention.id!)}
                    disabled={loading}
                    className="ml-4 p-2 rounded-lg text-stone-500 hover:text-red-400 hover:bg-red-900/20 transition-all duration-300 opacity-0 group-hover:opacity-100 disabled:opacity-30"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Sacred Footer */}
          <div className="mt-10 pt-8 border-t border-stone-700/40 text-center">
            <div className="text-rose-600/50 text-2xl mb-4 font-cinzel">⚜</div>
            <p className="text-sm text-stone-500 italic font-cormorant">
              "Orate pro invicem ut salvemini" - Rogai uns pelos outros para que sejais salvos
            </p>
            <p className="text-xs text-stone-600 mt-2 font-crimson">
              Tiago 5:16
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}