import React from 'react'
import { Crown, Heart, Star, Cross, BookOpen, UserPlus, LogOut } from 'lucide-react'
import { useIntentions } from '../hooks/useIntentions'
import { useAuth } from '../hooks/useAuth'

interface SidebarProps {
  currentSection: string
  onSectionChange: (section: string) => void
  onOpenIntentions: () => void
  onOpenAuth: () => void
  isAuthenticated: boolean
}

const sections = [
  { id: 'initium', title: 'Initium', subtitle: 'Início', icon: Cross },
  { id: 'gaudiosa', title: 'Mysteria Gaudiosa', subtitle: 'Mistérios Gozosos', icon: Star },
  { id: 'dolorosa', title: 'Mysteria Dolorosa', subtitle: 'Mistérios Dolorosos', icon: Heart },
  { id: 'gloriosa', title: 'Mysteria Gloriosa', subtitle: 'Mistérios Gloriosos', icon: Crown },
  { id: 'ultima', title: 'Ultima Oratio', subtitle: 'Última Oração', icon: BookOpen },
]

export function Sidebar({ currentSection, onSectionChange, onOpenIntentions, onOpenAuth, isAuthenticated }: SidebarProps) {
  const { intentions } = useIntentions()
  const { signOut, user } = useAuth()

  const handleSignOut = async () => {
    try {
      await signOut()
    } catch (error) {
      console.error('Error signing out:', error)
    }
  }

  return (
    <div className="fixed left-0 top-0 h-full w-80 bg-black/80 backdrop-blur-sm border-r border-stone-700/50 shadow-2xl">
      {/* Gothic stone texture overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-stone-800/5 via-stone-900/10 to-stone-800/5"></div>
      
      {/* Gothic architectural elements */}
      <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-amber-600/30 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-amber-600/30 to-transparent"></div>
      
      {/* Gothic corner details */}
      <div className="absolute top-4 left-4 text-amber-600/40 text-2xl font-cinzel">⚜</div>
      <div className="absolute top-4 right-4 text-amber-600/40 text-2xl font-cinzel">⚜</div>
      <div className="absolute bottom-4 left-4 text-amber-600/40 text-2xl font-cinzel">⚜</div>
      <div className="absolute bottom-4 right-4 text-amber-600/40 text-2xl font-cinzel">⚜</div>
      
      <div className="relative h-full p-8 flex flex-col">
        {/* Sacred Title */}
        <div className="text-center mb-8">
          <div className="text-amber-400 text-4xl mb-4 drop-shadow-2xl font-cinzel">✠</div>
          <h1 className="text-2xl font-bold text-amber-300 mb-2 drop-shadow-lg font-cinzel tracking-wide">
            Rosarium Virginis Marie
          </h1>
          <div className="w-32 h-px bg-gradient-to-r from-transparent via-amber-600/60 to-transparent mx-auto"></div>
          <p className="text-stone-400 text-sm mt-3 italic font-cormorant tracking-wider">
            "Ave Maria, gratia plena"
          </p>
        </div>

        {/* Authentication Section */}
        <div className="mb-6">
          {!isAuthenticated ? (
            <button
              onClick={onOpenAuth}
              className="w-full flex items-center justify-center space-x-3 p-4 bg-stone-900/40 border border-stone-600/40 rounded-lg text-stone-300 hover:bg-stone-800/50 hover:border-amber-600/40 hover:text-amber-200 transition-all duration-300 shadow-lg group"
            >
              <UserPlus className="w-5 h-5 group-hover:text-amber-400 transition-colors" />
              <span className="font-medium font-cormorant text-lg">
                Entrar / Registrar
              </span>
            </button>
          ) : (
            <div className="space-y-3">
              {/* User info */}
              <div className="text-center p-3 bg-stone-900/30 border border-stone-600/30 rounded-lg">
                <p className="text-stone-300 text-sm font-cormorant">
                  Conectado como:
                </p>
                <p className="text-amber-300 font-medium font-crimson truncate">
                  {user?.email}
                </p>
              </div>

              {/* Intentions button */}
              <button
                onClick={onOpenIntentions}
                className="w-full flex items-center justify-center space-x-3 p-4 bg-stone-900/40 border border-stone-600/40 rounded-lg text-stone-300 hover:bg-stone-800/50 hover:border-rose-600/40 hover:text-rose-200 transition-all duration-300 shadow-lg group"
              >
                <Heart className="w-5 h-5 group-hover:text-rose-400 transition-colors" />
                <span className="font-medium font-cormorant text-lg">
                  Intentiones Orationes
                </span>
              </button>
              
              {/* Intentions count */}
              {intentions.length > 0 && (
                <div className="text-center">
                  <div className="inline-flex items-center space-x-2 px-3 py-1 bg-stone-900/30 border border-rose-600/30 rounded-full">
                    <Heart className="w-3 h-3 text-rose-400" />
                    <span className="text-rose-300 text-sm font-cormorant">
                      {intentions.length} {intentions.length === 1 ? 'intenção' : 'intenções'}
                    </span>
                  </div>
                </div>
              )}

              {/* Sign out button */}
              <button
                onClick={handleSignOut}
                className="w-full flex items-center justify-center space-x-3 p-3 bg-stone-900/20 border border-stone-700/30 rounded-lg text-stone-400 hover:bg-stone-800/30 hover:border-stone-600/40 hover:text-stone-200 transition-all duration-300 text-sm"
              >
                <LogOut className="w-4 h-4" />
                <span className="font-cormorant">
                  Sair
                </span>
              </button>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="space-y-3 flex-1">
          {sections.map((section) => {
            const Icon = section.icon
            const isActive = currentSection === section.id
            
            return (
              <button
                key={section.id}
                onClick={() => onSectionChange(section.id)}
                className={`
                  w-full p-4 rounded-lg border transition-all duration-300 text-left group relative
                  ${isActive 
                    ? 'bg-stone-900/60 border-amber-600/50 shadow-lg shadow-amber-600/20' 
                    : 'bg-stone-900/20 border-stone-700/30 hover:bg-stone-900/40 hover:border-stone-600/50'
                  }
                `}
              >
                <div className="flex items-center space-x-4">
                  <div className={`p-2 rounded ${isActive ? 'bg-amber-600/20' : 'bg-stone-800/30'} transition-colors duration-300`}>
                    <Icon className={`w-5 h-5 ${isActive ? 'text-amber-400' : 'text-stone-400 group-hover:text-stone-300'} transition-colors duration-300`} />
                  </div>
                  <div>
                    <div className={`font-semibold ${isActive ? 'text-amber-300' : 'text-stone-300 group-hover:text-stone-200'} transition-colors duration-300 font-cormorant text-lg`}>
                      {section.title}
                    </div>
                    <div className={`text-sm ${isActive ? 'text-amber-400/70' : 'text-stone-500 group-hover:text-stone-400'} transition-colors duration-300 font-crimson`}>
                      {section.subtitle}
                    </div>
                  </div>
                </div>
              </button>
            )
          })}
        </nav>

        {/* Sacred Footer */}
        <div className="text-center mt-8 pt-6 border-t border-stone-700/40">
          <div className="text-amber-600/60 text-2xl mb-3 font-cinzel">⚜</div>
          <div className="text-xs text-stone-500 font-cormorant italic">
            Ad Majorem Dei Gloriam
          </div>
          <div className="text-xs text-stone-600 mt-1 font-crimson">
            Para a maior glória de Deus
          </div>
        </div>
      </div>
    </div>
  )
}