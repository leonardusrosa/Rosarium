import React from 'react'
import { Crown, Heart, Star, Cross, BookOpen } from 'lucide-react'
import { useIntentions } from '../hooks/useIntentions'

interface PrayerContentProps {
  section: string
  onOpenIntentions: () => void
  onOpenAuth: () => void
  isAuthenticated: boolean
}

const prayerSections = {
  initium: {
    title: 'Initium',
    subtitle: 'Início',
    icon: Cross,
    content: [
      {
        title: 'Signum Crucis',
        subtitle: 'Sinal da Cruz',
        latin: 'In nomine Patris, et Filii, et Spiritus Sancti. Amen.',
        portuguese: 'Em nome do Pai, e do Filho, e do Espírito Santo. Amém.'
      },
      {
        title: 'Offertorium Rosarii',
        subtitle: 'Oferecimento do Rosário',
        latin: 'Divino Jesu, nos Vos oferecemos este terço que vamos rezar, meditando nos mistérios da Vossa Redenção. Concedeí-nos, pela intercessão da Virgem Maria, Mãe Vossa e nossa, as virtudes que nos são necessárias para bem rezá-lo e a graça de ganharmos as indulgências desta santa devoção.',
        portuguese: 'Divino Jesus, nós Vos oferecemos este terço que vamos rezar, meditando nos mistérios da Vossa Redenção. Concedei-nos, pela intercessão da Virgem Maria, Mãe Vossa e nossa, as virtudes que nos são necessárias para bem rezá-lo e a graça de ganharmos as indulgências desta santa devoção.'
      },
      {
        title: 'Credo',
        subtitle: 'Creio em Deus Pai',
        latin: 'Credo in Deum Patrem omnipotentem, Creatorem caeli et terrae, et in Jesum Christum, Filium ejus unicum, Dominum nostrum, qui conceptus est de Spiritu Sancto, natus ex Maria Virgine, passus sub Pontio Pilato, crucifixus, mortuus, et sepultus, descendit ad inferos, tertia die resurrexit a mortuis, ascendit ad caelos, sedet ad dexteram Dei Patris omnipotentis, inde venturus est judicare vivos et mortuos. Credo in Spiritum Sanctum, sanctam Ecclesiam catholicam, sanctorum communionem, remissionem peccatorum, carnis resurrectionem, vitam aeternam. Amen.',
        portuguese: 'Creio em Deus Pai todo-poderoso, Criador do céu e da terra, e em Jesus Cristo, seu único Filho, nosso Senhor, que foi concebido pelo poder do Espírito Santo, nasceu da Virgem Maria, padeceu sob Pôncio Pilatos, foi crucificado, morto e sepultado, desceu à mansão dos mortos, ressuscitou ao terceiro dia, subiu aos céus, está sentado à direita de Deus Pai todo-poderoso, donde há de vir a julgar os vivos e os mortos. Creio no Espírito Santo, na Santa Igreja Católica, na comunhão dos santos, na remissão dos pecados, na ressurreição da carne, na vida eterna. Amém.'
      }
    ]
  },
  gaudiosa: {
    title: 'Mysteria Gaudiosa',
    subtitle: 'Mistérios Gozosos',
    icon: Star,
    content: [
      {
        title: 'Primum Mysterium Gaudiosum',
        subtitle: 'A Anunciação do Anjo a Nossa Senhora',
        meditation: 'Contemplemos como o Anjo Gabriel anunciou a Nossa Senhora que Ela seria a Mãe do Salvador, e como Ela humildemente consentiu, dizendo: "Eis aqui a serva do Senhor, faça-se em mim segundo a vossa palavra."',
        fruit: 'Fruto do mistério: A Humildade'
      },
      {
        title: 'Secundum Mysterium Gaudiosum',
        subtitle: 'A Visitação de Nossa Senhora a Santa Isabel',
        meditation: 'Contemplemos como Nossa Senhora, depois de saber que seria Mãe de Deus, foi visitar Santa Isabel, sua prima, e como ao som da sua saudação, Santa Isabel ficou cheia do Espírito Santo.',
        fruit: 'Fruto do mistério: A Caridade Fraterna'
      },
      {
        title: 'Tertium Mysterium Gaudiosum',
        subtitle: 'O Nascimento de Jesus em Belém',
        meditation: 'Contemplemos como Nosso Senhor Jesus Cristo nasceu em Belém, numa noite fria, numa gruta, e foi posto numa manjedoura entre dois animais.',
        fruit: 'Fruto do mistério: O Espírito de Pobreza'
      },
      {
        title: 'Quartum Mysterium Gaudiosum',
        subtitle: 'A Apresentação do Menino Jesus no Templo',
        meditation: 'Contemplemos como a Santíssima Virgem apresentou o Menino Jesus no templo pelas mãos do santo velho Simeão.',
        fruit: 'Fruto do mistério: A Obediência'
      },
      {
        title: 'Quintum Mysterium Gaudiosum',
        subtitle: 'O Encontro do Menino Jesus no Templo',
        meditation: 'Contemplemos como a Santíssima Virgem encontrou o Menino Jesus no templo entre os doutores, depois de O ter perdido por três dias.',
        fruit: 'Fruto do mistério: A Busca de Jesus'
      }
    ]
  },
  dolorosa: {
    title: 'Mysteria Dolorosa',
    subtitle: 'Mistérios Dolorosos',
    icon: Heart,
    content: [
      {
        title: 'Primum Mysterium Dolorosum',
        subtitle: 'A Agonia de Jesus no Horto',
        meditation: 'Contemplemos como Nosso Senhor Jesus Cristo suou sangue no Horto das Oliveiras, considerando os nossos pecados e os tormentos que havia de padecer.',
        fruit: 'Fruto do mistério: A Contrição dos Pecados'
      },
      {
        title: 'Secundum Mysterium Dolorosum',
        subtitle: 'A Flagelação de Nosso Senhor',
        meditation: 'Contemplemos como Jesus foi cruelmente flagelado e como o seu Corpo Sagrado foi todo dilacerado para satisfazer pela nossa sensualidade.',
        fruit: 'Fruto do mistério: A Mortificação'
      },
      {
        title: 'Tertium Mysterium Dolorosum',
        subtitle: 'A Coroação de Espinhos',
        meditation: 'Contemplemos como Nosso Senhor Jesus Cristo foi coroado de espinhos e como foi escarnecido e ultrajado para satisfazer pelo nosso orgulho.',
        fruit: 'Fruto do mistério: A Humildade'
      },
      {
        title: 'Quartum Mysterium Dolorosum',
        subtitle: 'Jesus Carrega a Cruz',
        meditation: 'Contemplemos como Jesus carregou a cruz às costas para o lugar do suplício.',
        fruit: 'Fruto do mistério: A Paciência'
      },
      {
        title: 'Quintum Mysterium Dolorosum',
        subtitle: 'A Crucificação e Morte de Nosso Senhor',
        meditation: 'Contemplemos como Nosso Senhor Jesus Cristo foi crucificado entre dois ladrões, morreu na cruz e foi sepultado.',
        fruit: 'Fruto do mistério: O Amor de Deus'
      }
    ]
  },
  gloriosa: {
    title: 'Mysteria Gloriosa',
    subtitle: 'Mistérios Gloriosos',
    icon: Crown,
    content: [
      {
        title: 'Primum Mysterium Gloriosum',
        subtitle: 'A Ressurreição de Nosso Senhor',
        meditation: 'Contemplemos como Nosso Senhor Jesus Cristo ressuscitou glorioso e imortal ao terceiro dia depois de sua morte.',
        fruit: 'Fruto do mistério: A Fé'
      },
      {
        title: 'Secundum Mysterium Gloriosum',
        subtitle: 'A Ascensão de Nosso Senhor',
        meditation: 'Contemplemos como Nosso Senhor Jesus Cristo, quarenta dias depois da sua Ressurreição, subiu por si mesmo aos céus à vista de sua Mãe Santíssima e dos Apóstolos.',
        fruit: 'Fruto do mistério: A Esperança'
      },
      {
        title: 'Tertium Mysterium Gloriosum',
        subtitle: 'A Vinda do Espírito Santo',
        meditation: 'Contemplemos como o Espírito Santo desceu sobre a Santíssima Virgem e os Apóstolos em forma de línguas de fogo.',
        fruit: 'Fruto do mistério: O Amor de Deus'
      },
      {
        title: 'Quartum Mysterium Gloriosum',
        subtitle: 'A Assunção de Nossa Senhora',
        meditation: 'Contemplemos como a Santíssima Virgem foi elevada em corpo e alma aos céus pelos anjos.',
        fruit: 'Fruto do mistério: A Devoção a Maria'
      },
      {
        title: 'Quintum Mysterium Gloriosum',
        subtitle: 'A Coroação de Nossa Senhora',
        meditation: 'Contemplemos como a Santíssima Virgem foi coroada no céu pela Santíssima Trindade.',
        fruit: 'Fruto do mistério: A Perseverança Final'
      }
    ]
  },
  ultima: {
    title: 'Ultima Oratio',
    subtitle: 'Última Oração',
    icon: BookOpen,
    content: [
      {
        title: 'Salve Regina',
        subtitle: 'Salvé, Rainha',
        latin: 'Salve, Regina, Mater misericordiae, vita, dulcedo et spes nostra, salve. Ad te clamamus, exsules filii Hevae. Ad te suspiramus gementes et flentes in hac lacrimarum valle. Eia ergo, advocata nostra, illos tuos misericordes oculos ad nos converte. Et Jesum, benedictum fructum ventris tui, nobis, post hoc exsilium, ostende. O clemens, o pia, o dulcis Virgo Maria.',
        portuguese: 'Salvé, Rainha, Mãe de misericórdia, vida, doçura e esperança nossa, salvé! A vós bradamos, os degredados filhos de Eva. A vós suspiramos, gemendo e chorando neste vale de lágrimas. Eia, pois, advogada nossa, esses vossos olhos misericordiosos a nós volvei. E depois deste desterro, mostrai-nos Jesus, bendito fruto do vosso ventre. Ó clemente, ó piedosa, ó doce sempre Virgem Maria.'
      },
      {
        title: 'Oratio Finalis',
        subtitle: 'Oração Final',
        latin: 'Ora pro nobis, sancta Dei Genetrix, ut digni efficiamur promissionibus Christi.',
        portuguese: 'Rogai por nós, Santa Mãe de Deus, para que sejamos dignos das promessas de Cristo.'
      }
    ]
  }
}

export function PrayerContent({ section, onOpenIntentions, onOpenAuth, isAuthenticated }: PrayerContentProps) {
  const { intentions } = useIntentions()
  const currentSection = prayerSections[section as keyof typeof prayerSections]

  if (!currentSection) return null

  const Icon = currentSection.icon

  return (
    <div className="ml-80 min-h-screen p-8 relative">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-6 mb-8">
            <div className="p-4 bg-stone-900/40 rounded-lg border border-amber-600/30 shadow-lg">
              <Icon className="w-10 h-10 text-amber-400" />
            </div>
            <div>
              <h1 className="text-5xl font-bold text-amber-300 mb-3 font-cinzel tracking-wide">
                {currentSection.title}
              </h1>
              <p className="text-2xl text-stone-400 font-cormorant">
                {currentSection.subtitle}
              </p>
            </div>
          </div>
          <div className="w-48 h-px bg-gradient-to-r from-transparent via-amber-600/50 to-transparent mx-auto"></div>
        </div>

        {/* Display Intentions in Initium section */}
        {section === 'initium' && isAuthenticated && intentions.length > 0 && (
          <div className="mb-16">
            <div className="bg-stone-900/30 backdrop-blur-sm rounded-lg border border-stone-700/40 p-8 shadow-lg relative">
              {/* Gothic architectural elements */}
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-rose-600/40 to-transparent"></div>
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-rose-600/40 to-transparent"></div>
              
              {/* Gothic corner details */}
              <div className="absolute top-3 left-3 text-rose-600/30 text-xl font-cinzel">⚜</div>
              <div className="absolute top-3 right-3 text-rose-600/30 text-xl font-cinzel">⚜</div>
              <div className="absolute bottom-3 left-3 text-rose-600/30 text-xl font-cinzel">⚜</div>
              <div className="absolute bottom-3 right-3 text-rose-600/30 text-xl font-cinzel">⚜</div>
              
              <div className="relative">
                <div className="text-center mb-8">
                  <div className="flex items-center justify-center space-x-3 mb-4">
                    <Heart className="w-8 h-8 text-rose-400" />
                    <h3 className="text-3xl font-bold text-rose-300 font-cinzel">
                      Intentiones Particulares
                    </h3>
                    <Heart className="w-8 h-8 text-rose-400" />
                  </div>
                  <p className="text-rose-400/70 italic font-cormorant text-lg">
                    "Orate pro invicem" - Rogai uns pelos outros
                  </p>
                </div>
                
                <div className="grid gap-4">
                  {intentions.map((intention, index) => (
                    <div key={intention.id} className="flex items-start space-x-4 p-6 bg-stone-900/20 rounded-lg border border-stone-700/30">
                      <div className="flex-shrink-0 mt-1">
                        <div className="w-8 h-8 bg-stone-800/40 rounded-full border border-rose-500/30 flex items-center justify-center">
                          <Heart className="w-4 h-4 text-rose-400" />
                        </div>
                      </div>
                      <p className="text-stone-200 leading-relaxed text-lg font-crimson">
                        {intention.intention}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Prayer Content */}
        <div className="space-y-16">
          {currentSection.content.map((prayer, index) => (
            <div key={index} className="bg-stone-900/30 backdrop-blur-sm rounded-lg border border-stone-700/40 p-10 shadow-lg relative">
              {/* Gothic architectural elements */}
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-600/40 to-transparent"></div>
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-600/40 to-transparent"></div>
              
              {/* Gothic corner details */}
              <div className="absolute top-3 left-3 text-amber-600/30 text-xl font-cinzel">⚜</div>
              <div className="absolute top-3 right-3 text-amber-600/30 text-xl font-cinzel">⚜</div>
              <div className="absolute bottom-3 left-3 text-amber-600/30 text-xl font-cinzel">⚜</div>
              <div className="absolute bottom-3 right-3 text-amber-600/30 text-xl font-cinzel">⚜</div>
              
              <div className="relative">
                <div className="text-center mb-10">
                  <h3 className="text-3xl font-bold text-amber-300 mb-3 font-cinzel">
                    {prayer.title}
                  </h3>
                  {prayer.subtitle && (
                    <p className="text-xl text-stone-400 mb-4 font-cormorant">
                      {prayer.subtitle}
                    </p>
                  )}
                  <div className="w-24 h-px bg-gradient-to-r from-transparent via-amber-600/50 to-transparent mx-auto"></div>
                </div>

                {prayer.meditation && (
                  <div className="mb-10 p-8 bg-stone-900/20 rounded-lg border border-stone-700/30">
                    <div className="text-center mb-4">
                      <h4 className="text-lg font-semibold text-stone-300 font-cormorant">
                        Meditação
                      </h4>
                    </div>
                    <p className="text-stone-300 text-center leading-relaxed text-lg font-crimson">
                      {prayer.meditation}
                    </p>
                    {prayer.fruit && (
                      <div className="mt-6 text-center">
                        <p className="text-amber-400 italic font-cormorant">
                          {prayer.fruit}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                <div className="grid lg:grid-cols-2 gap-10">
                  {prayer.latin && (
                    <div className="space-y-4">
                      <h4 className="text-xl font-semibold text-amber-400 text-center font-cormorant">
                        Latine
                      </h4>
                      <div className="p-6 bg-stone-900/20 rounded-lg border border-stone-700/20">
                        <p className="text-stone-200 leading-relaxed italic text-lg font-crimson">
                          {prayer.latin}
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {prayer.portuguese && (
                    <div className="space-y-4">
                      <h4 className="text-xl font-semibold text-rose-400 text-center font-cormorant">
                        Português
                      </h4>
                      <div className="p-6 bg-stone-900/20 rounded-lg border border-stone-700/20">
                        <p className="text-stone-200 leading-relaxed text-lg font-crimson">
                          {prayer.portuguese}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Sacred decorative elements */}
                <div className="text-center mt-10">
                  <div className="text-amber-600/50 text-3xl font-cinzel">⚜</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Sacred Footer */}
        <div className="text-center mt-20 mb-12">
          <div className="text-amber-600/60 text-5xl mb-6 font-cinzel">✠</div>
          <p className="text-stone-400 text-xl mb-2 font-cormorant">
            Ora pro nobis, sancta Dei Genetrix, ut digni efficiamur promissionibus Christi
          </p>
          <p className="text-stone-500 text-lg font-crimson">
            Rogai por nós, Santa Mãe de Deus, para que sejamos dignos das promessas de Cristo
          </p>
        </div>
      </div>
    </div>
  )
}