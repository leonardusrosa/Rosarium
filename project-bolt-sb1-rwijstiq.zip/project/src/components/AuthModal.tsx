import React, { useState } from 'react'
import { X, User, Lock, Mail } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'

interface AuthModalProps {
  isOpen: boolean
  onClose: () => void
}

export function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { signIn, signUp } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const { error } = isSignUp 
        ? await signUp(email, password)
        : await signIn(email, password)

      if (error) {
        setError(error.message)
      } else {
        onClose()
        setEmail('')
        setPassword('')
      }
    } catch (err) {
      setError('Ocorreu um erro inesperado')
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      {/* Gothic cathedral backdrop */}
      <div className="absolute inset-0 bg-black/90 backdrop-blur-sm"></div>
      
      {/* Modal */}
      <div 
        className="relative bg-stone-900/90 backdrop-blur-sm rounded-lg border border-stone-700/50 max-w-md w-full shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Gothic architectural elements */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-amber-600/40 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full h-2 bg-gradient-to-r from-transparent via-amber-600/40 to-transparent"></div>
        
        {/* Gothic corner details */}
        <div className="absolute top-4 left-4 text-amber-600/30 text-2xl font-cinzel">⚜</div>
        <div className="absolute top-4 right-4 text-amber-600/30 text-2xl font-cinzel">⚜</div>
        <div className="absolute bottom-4 left-4 text-amber-600/30 text-2xl font-cinzel">⚜</div>
        <div className="absolute bottom-4 right-4 text-amber-600/30 text-2xl font-cinzel">⚜</div>
        
        <div className="relative p-10">
          {/* Sacred Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold text-amber-300 font-cinzel">
                {isSignUp ? 'Registrar' : 'Entrar'}
              </h2>
              <p className="text-stone-400 mt-1 font-cormorant">
                {isSignUp ? 'Criar nova conta' : 'Acesse sua conta'}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-3 rounded-lg hover:bg-stone-800/50 transition-all duration-300 text-stone-400 hover:text-stone-200"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-stone-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-stone-900/40 border border-stone-700/40 rounded-lg text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-600/50 focus:ring-2 focus:ring-amber-600/20 transition-all duration-300 font-crimson"
                />
              </div>
            </div>

            <div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-stone-500" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Senha"
                  required
                  className="w-full pl-12 pr-4 py-4 bg-stone-900/40 border border-stone-700/40 rounded-lg text-stone-200 placeholder-stone-500 focus:outline-none focus:border-amber-600/50 focus:ring-2 focus:ring-amber-600/20 transition-all duration-300 font-crimson"
                />
              </div>
            </div>

            {error && (
              <div className="text-red-400 text-center p-3 bg-red-900/20 border border-red-600/30 rounded-lg font-crimson">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-stone-800/40 border border-amber-600/30 rounded-lg text-amber-300 hover:bg-stone-700/50 hover:border-amber-500/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 font-semibold font-cormorant text-lg"
            >
              {loading ? 'Aguarde...' : (isSignUp ? 'Registrar' : 'Entrar')}
            </button>
          </form>

          {/* Toggle */}
          <div className="mt-8 text-center">
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-stone-400 hover:text-stone-200 transition-colors underline decoration-stone-600/50 hover:decoration-stone-400/70 font-cormorant"
            >
              {isSignUp 
                ? 'Já tem conta? Entrar' 
                : 'Não tem conta? Registrar'
              }
            </button>
          </div>

          {/* Sacred Footer */}
          <div className="mt-8 pt-6 border-t border-stone-700/40 text-center">
            <div className="text-amber-600/50 text-2xl mb-2 font-cinzel">✠</div>
            <p className="text-xs text-stone-500 italic font-cormorant">
              "Venite ad me omnes" - Vinde a mim todos
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}