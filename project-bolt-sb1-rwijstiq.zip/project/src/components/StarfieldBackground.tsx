import React, { useEffect, useRef } from 'react'

interface Star {
  x: number
  y: number
  z: number
  brightness: number
  speed: number
  twinkle: number
  size: number
  color: { r: number; g: number; b: number }
}

interface AuroraWave {
  x: number
  y: number
  amplitude: number
  frequency: number
  phase: number
  speed: number
  color: { r: number; g: number; b: number; a: number }
}

export function StarfieldBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const starsRef = useRef<Star[]>([])
  const auroraWavesRef = useRef<AuroraWave[]>([])
  const animationRef = useRef<number>()
  const timeRef = useRef<number>(0)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    const createStars = () => {
      const stars: Star[] = []
      const numStars = 1500

      for (let i = 0; i < numStars; i++) {
        const brightness = Math.random()
        let color = { r: 255, g: 255, b: 255 }
        
        // Create realistic star colors based on stellar classification
        if (brightness > 0.9) {
          // Blue-white giants (very rare)
          color = { r: 180, g: 200, b: 255 }
        } else if (brightness > 0.7) {
          // White stars
          color = { r: 255, g: 255, b: 255 }
        } else if (brightness > 0.5) {
          // Yellow-white stars (like our Sun)
          color = { r: 255, g: 250, b: 220 }
        } else if (brightness > 0.3) {
          // Orange stars
          color = { r: 255, g: 220, b: 180 }
        } else {
          // Red dwarfs (most common)
          color = { r: 255, g: 180, b: 120 }
        }

        stars.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          z: Math.random() * 1000,
          brightness: brightness * 0.8 + 0.2,
          speed: Math.random() * 0.05 + 0.01,
          twinkle: Math.random() * Math.PI * 2,
          size: Math.random() * 1.2 + 0.3,
          color
        })
      }

      starsRef.current = stars
    }

    const createAurora = () => {
      const waves: AuroraWave[] = []
      
      // Create multiple aurora layers with different characteristics
      const layers = [
        { baseY: 0.15, color: { r: 0, g: 255, b: 150, a: 0.08 }, count: 8 },
        { baseY: 0.25, color: { r: 100, g: 255, b: 200, a: 0.06 }, count: 6 },
        { baseY: 0.35, color: { r: 150, g: 100, b: 255, a: 0.04 }, count: 4 }
      ]

      layers.forEach(layer => {
        for (let i = 0; i < layer.count; i++) {
          waves.push({
            x: (canvas.width / layer.count) * i,
            y: canvas.height * layer.baseY + Math.random() * 50,
            amplitude: Math.random() * 80 + 40,
            frequency: Math.random() * 0.02 + 0.01,
            phase: Math.random() * Math.PI * 2,
            speed: Math.random() * 0.01 + 0.005,
            color: layer.color
          })
        }
      })

      auroraWavesRef.current = waves
    }

    const drawAurora = () => {
      const waves = auroraWavesRef.current
      
      // Group waves by color for better blending
      const colorGroups = waves.reduce((groups, wave) => {
        const key = `${wave.color.r}-${wave.color.g}-${wave.color.b}`
        if (!groups[key]) groups[key] = []
        groups[key].push(wave)
        return groups
      }, {} as Record<string, AuroraWave[]>)

      Object.values(colorGroups).forEach(groupWaves => {
        if (groupWaves.length === 0) return
        
        const firstWave = groupWaves[0]
        
        // Create vertical gradient for this color group
        const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height * 0.6)
        gradient.addColorStop(0, `rgba(${firstWave.color.r}, ${firstWave.color.g}, ${firstWave.color.b}, ${firstWave.color.a})`)
        gradient.addColorStop(0.4, `rgba(${firstWave.color.r}, ${firstWave.color.g}, ${firstWave.color.b}, ${firstWave.color.a * 0.6})`)
        gradient.addColorStop(0.8, `rgba(${firstWave.color.r}, ${firstWave.color.g}, ${firstWave.color.b}, ${firstWave.color.a * 0.2})`)
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)')

        ctx.fillStyle = gradient
        ctx.globalCompositeOperation = 'screen'
        
        // Draw flowing aurora curtains
        ctx.beginPath()
        
        // Start from left edge
        const firstPoint = groupWaves[0]
        const firstY = firstPoint.y + Math.sin(timeRef.current * firstPoint.speed + firstPoint.phase) * firstPoint.amplitude
        ctx.moveTo(0, firstY)
        
        // Create smooth curves through all wave points
        for (let i = 0; i < groupWaves.length; i++) {
          const wave = groupWaves[i]
          const waveY = wave.y + Math.sin(timeRef.current * wave.speed + wave.phase) * wave.amplitude
          
          if (i === 0) {
            ctx.lineTo(wave.x, waveY)
          } else {
            const prevWave = groupWaves[i - 1]
            const prevY = prevWave.y + Math.sin(timeRef.current * prevWave.speed + prevWave.phase) * prevWave.amplitude
            const cpX = (prevWave.x + wave.x) / 2
            const cpY = (prevY + waveY) / 2
            ctx.quadraticCurveTo(cpX, cpY, wave.x, waveY)
          }
        }
        
        // Complete the curtain shape
        ctx.lineTo(canvas.width, firstY)
        ctx.lineTo(canvas.width, canvas.height * 0.6)
        ctx.lineTo(0, canvas.height * 0.6)
        ctx.closePath()
        ctx.fill()
        
        ctx.globalCompositeOperation = 'source-over'
      })
    }

    const animate = () => {
      timeRef.current += 0.016 // ~60fps timing

      // Clear canvas with deep space black
      ctx.fillStyle = '#000008'
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Add subtle cosmic dust/nebula
      const nebulaGradient = ctx.createRadialGradient(
        canvas.width * 0.7, canvas.height * 0.3, 0,
        canvas.width * 0.7, canvas.height * 0.3, canvas.width * 0.6
      )
      nebulaGradient.addColorStop(0, 'rgba(60, 40, 80, 0.015)')
      nebulaGradient.addColorStop(0.5, 'rgba(40, 60, 100, 0.01)')
      nebulaGradient.addColorStop(1, 'rgba(0, 0, 0, 0)')
      
      ctx.fillStyle = nebulaGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw aurora first (behind stars)
      drawAurora()

      // Draw stars
      starsRef.current.forEach(star => {
        // Very subtle stellar movement
        star.y += star.speed * 0.3
        star.x += Math.sin(timeRef.current * 0.3 + star.twinkle) * 0.02
        
        // Reset star position when it goes off screen
        if (star.y > canvas.height + 10) {
          star.y = -10
          star.x = Math.random() * canvas.width
        }

        // Calculate star properties based on distance
        const depth = (1000 - star.z) / 1000
        const size = star.size * depth
        const twinkleEffect = Math.sin(timeRef.current * 2 + star.twinkle) * 0.3 + 0.7
        const finalBrightness = star.brightness * depth * twinkleEffect

        // Only draw visible stars
        if (finalBrightness > 0.1 && size > 0.1) {
          // Main star body
          ctx.fillStyle = `rgba(${star.color.r}, ${star.color.g}, ${star.color.b}, ${finalBrightness})`
          ctx.beginPath()
          ctx.arc(star.x, star.y, size, 0, Math.PI * 2)
          ctx.fill()

          // Atmospheric glow for brighter stars
          if (finalBrightness > 0.5) {
            const glowSize = size * 3
            const glowGradient = ctx.createRadialGradient(star.x, star.y, 0, star.x, star.y, glowSize)
            glowGradient.addColorStop(0, `rgba(${star.color.r}, ${star.color.g}, ${star.color.b}, ${finalBrightness * 0.2})`)
            glowGradient.addColorStop(1, 'rgba(255, 255, 255, 0)')
            
            ctx.fillStyle = glowGradient
            ctx.beginPath()
            ctx.arc(star.x, star.y, glowSize, 0, Math.PI * 2)
            ctx.fill()
          }

          // Diffraction spikes for very bright stars
          if (finalBrightness > 0.8) {
            ctx.strokeStyle = `rgba(${star.color.r}, ${star.color.g}, ${star.color.b}, ${finalBrightness * 0.3})`
            ctx.lineWidth = 0.5
            ctx.beginPath()
            
            const spikeLength = size * 8
            // Vertical spike
            ctx.moveTo(star.x, star.y - spikeLength)
            ctx.lineTo(star.x, star.y + spikeLength)
            
            // Horizontal spike
            ctx.moveTo(star.x - spikeLength, star.y)
            ctx.lineTo(star.x + spikeLength, star.y)
            
            ctx.stroke()
          }
        }
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    resizeCanvas()
    createStars()
    createAurora()
    animate()

    const handleResize = () => {
      resizeCanvas()
      createStars()
      createAurora()
    }

    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 1 }}
    />
  )
}